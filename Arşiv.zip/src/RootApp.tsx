import React, { Suspense, lazy } from "react";
import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./lib/AuthContext";
import { getPendingInvitationToken } from "./lib/invitationConstants";
import { OrganizationProvider, useOrganization } from "./lib/OrganizationContext";
import { CrmProvider } from "./lib/CrmContext";
import AuthLoadingScreen from "./components/auth/AuthLoadingScreen";
import LoginPage from "./components/auth/LoginPage";
import RegisterPage from "./components/auth/RegisterPage";
import ForgotPasswordPage from "./components/auth/ForgotPasswordPage";
import ResetPasswordPage from "./components/auth/ResetPasswordPage";
import JoinPage from "./components/auth/JoinPage";
import WelcomeWizard from "./components/onboarding/WelcomeWizard";

const App = lazy(() => import("./App"));

function ProtectedApp() {
  const { user } = useAuth();
  const { needsOnboarding, loading: orgLoading } = useOrganization();
  const location = useLocation();
  const pendingInvitationToken = getPendingInvitationToken();

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  if (orgLoading) {
    return <AuthLoadingScreen />;
  }

  if (needsOnboarding) {
    if (pendingInvitationToken) {
      return <Navigate to={`/join?token=${encodeURIComponent(pendingInvitationToken)}`} replace />;
    }
    return <WelcomeWizard />;
  }

  return (
    <CrmProvider>
      <Suspense fallback={<AuthLoadingScreen />}>
        <App />
      </Suspense>
    </CrmProvider>
  );
}

function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) {
    return <AuthLoadingScreen />;
  }

  return (
    <OrganizationProvider>
      <Routes>
        <Route path="/join" element={<JoinPage />} />
        <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
        <Route path="/register" element={user ? <Navigate to="/" replace /> : <RegisterPage />} />
        <Route path="/forgot-password" element={user ? <Navigate to="/" replace /> : <ForgotPasswordPage />} />
        <Route path="/reset-password" element={user ? <Navigate to="/" replace /> : <ResetPasswordPage />} />
        <Route path="/*" element={<ProtectedApp />} />
      </Routes>
    </OrganizationProvider>
  );
}

export default function RootApp() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}
